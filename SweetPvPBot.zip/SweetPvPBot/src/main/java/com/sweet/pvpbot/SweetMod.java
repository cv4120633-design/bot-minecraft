package com.sweet.pvpbot;

import com.sweet.pvpbot.command.SweetCommands;
import com.sweet.pvpbot.config.SweetConfig;
import com.sweet.pvpbot.entity.ModEntities;
import net.fabricmc.api.ModInitializer;

import java.util.logging.Logger;

/**
 * الكلاس الرئيسي لمود Sweet PvP Bot.
 *
 * ملاحظة مهمة: ابتداءً من Minecraft 26.1 بقت اللعبة "unobfuscated" وبقى الموددرز
 * بيستخدموا أسماء (Mappings) موجانج الرسمية مباشرة بدل Yarn، يعني أسماء كذا كلاس
 * ممكن تكون مختلفة عن الكود القديم (مثلاً World ممكن تبقى Level، PlayerEntity
 * ممكن تبقى Player... إلخ). الكود ده مكتوب بأسماء Yarn المعروفة (ZombieEntity,
 * PlayerEntity, ServerWorld...) عشان تفهم المنطق، لكن لازم تتأكد من الأسماء
 * الصحيحة في بيئتك عن طريق الـ IDE (auto-complete) أو توثيق Fabric لإصدار 26.1.2
 * قبل ما تعمل build نهائي، لأن المابينج اتغيرت فعليًا في النسخة دي.
 */
public class SweetMod implements ModInitializer {

    public static final String MOD_ID = "sweetpvpbot";
    public static final Logger LOGGER = Logger.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("[Sweet] بدء تحميل مود Sweet PvP Bot...");

        SweetConfig.load();
        ModEntities.register();
        SweetCommands.register();

        LOGGER.info("[Sweet] تم التحميل بنجاح.");
    }
}
