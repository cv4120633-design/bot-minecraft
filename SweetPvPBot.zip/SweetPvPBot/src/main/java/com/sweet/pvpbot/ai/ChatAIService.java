package com.sweet.pvpbot.ai;

import com.sweet.pvpbot.SweetMod;
import com.sweet.pvpbot.config.SweetConfig;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * خدمة بسيطة بترسل الرسالة لموديل شات (متوافق مع صيغة OpenAI Chat Completions API)
 * وترجع الرد كنص. الاتصال بيحصل في Thread منفصل (async) عشان ما يعملش تجميد
 * (lag/freeze) للسيرفر أثناء انتظار الرد.
 *
 * لازم تحط الـ API Key بتاعك في ملف config/sweetpvpbot.json (شوف SweetConfig).
 */
public final class ChatAIService {

    private static final ChatAIService INSTANCE = new ChatAIService();

    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10))
            .build();

    public static ChatAIService getInstance() {
        return INSTANCE;
    }

    private ChatAIService() {}

    /**
     * يبعت الرسالة للـ API ويرجع الرد عن طريق الـ callback (onReply)
     * اللي بيتنفذ برضو مش على الـ main server thread، فلازم اللي بيستخدمه
     * يرجع للـ main thread بتاع السيرفر قبل ما يبعت الرد في الشات
     * (شوف SweetCommands.java لتفاصيل الاستخدام الصحيح).
     */
    public void askAsync(String userMessage, Consumer<String> onReply) {
        CompletableFuture.runAsync(() -> {
            try {
                String reply = ask(userMessage);
                onReply.accept(reply);
            } catch (Exception e) {
                SweetMod.LOGGER.warning("[Sweet] فشل الاتصال بالـ AI API: " + e.getMessage());
                onReply.accept("معلش، مش قادر أرد دلوقتي (حصل خطأ في الاتصال بالـ API).");
            }
        });
    }

    private String ask(String userMessage) throws Exception {
        SweetConfig config = SweetConfig.get();

        String escapedMessage = escapeJson(userMessage);
        String escapedSystemPrompt = escapeJson(
                "انت بوت اسمك Sweet جوه لعبة ماين كرافت, بتلعب PvP وكمان بترد على اللاعبين "
                        + "بالكلام بشكل ودود ومختصر."
        );

        String requestBody = "{"
                + "\"model\":\"" + escapeJson(config.model) + "\","
                + "\"messages\":["
                + "{\"role\":\"system\",\"content\":\"" + escapedSystemPrompt + "\"},"
                + "{\"role\":\"user\",\"content\":\"" + escapedMessage + "\"}"
                + "],"
                + "\"max_tokens\":200"
                + "}";

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(config.apiEndpoint))
                .timeout(Duration.ofSeconds(20))
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + config.apiKey)
                .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() != 200) {
            throw new RuntimeException("HTTP " + response.statusCode() + ": " + response.body());
        }

        return extractContent(response.body());
    }

    /**
     * استخراج بسيط لحقل "content" من رد JSON بصيغة OpenAI، من غير الاعتماد
     * على مكتبة JSON خارجية. لو محتاج تحليل أدق، ينفع تضيف مكتبة زي Gson.
     */
    private String extractContent(String json) {
        Pattern pattern = Pattern.compile("\"content\"\\s*:\\s*\"(.*?)(?<!\\\\)\"", Pattern.DOTALL);
        Matcher matcher = pattern.matcher(json);
        if (matcher.find()) {
            return unescapeJson(matcher.group(1));
        }
        return "معلش، مش فاهم الرد اللي رجع من الـ API.";
    }

    private String escapeJson(String text) {
        return text.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "");
    }

    private String unescapeJson(String text) {
        return text.replace("\\n", "\n")
                .replace("\\\"", "\"")
                .replace("\\\\", "\\");
    }
}
