package com.sweet.pvpbot.command;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.sweet.pvpbot.entity.ModEntities;
import com.sweet.pvpbot.entity.SweetBotEntity;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.List;

import static com.mojang.brigadier.arguments.StringArgumentType.getString;
import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

/**
 * أوامر المود:
 *   /sweet spawn        -> يستدعي بوت Sweet جنب اللاعب اللي كتب الأمر
 *   /sweet chat <رسالة> -> يبعت رسالة لأقرب بوت Sweet وياخد رد بالذكاء الاصطناعي
 */
public final class SweetCommands {

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(literal("sweet")
                    .then(literal("spawn").executes(SweetCommands::spawnSweet))
                    .then(literal("chat")
                            .then(argument("message", StringArgumentType.greedyString())
                                    .executes(SweetCommands::chatWithSweet))));
        });
    }

    private static int spawnSweet(com.mojang.brigadier.context.CommandContext<ServerCommandSource> context) {
        ServerCommandSource source = context.getSource();
        ServerPlayerEntity player = source.getPlayer();
        if (player == null) {
            source.sendError(Text.literal("لازم تشغل الأمر ده كـ Player."));
            return 0;
        }

        SweetBotEntity sweet = new SweetBotEntity(ModEntities.SWEET_BOT, player.getWorld());
        sweet.refreshPositionAndAngles(
                player.getX() + 2, player.getY(), player.getZ(),
                player.getYaw(), 0
        );
        player.getWorld().spawnEntity(sweet);

        source.sendFeedback(() -> Text.literal("تم استدعاء Sweet!"), false);
        return 1;
    }

    private static int chatWithSweet(com.mojang.brigadier.context.CommandContext<ServerCommandSource> context) {
        ServerCommandSource source = context.getSource();
        String message = getString(context, "message");

        List<SweetBotEntity> nearbySweets = source.getWorld().getEntitiesByClass(
                SweetBotEntity.class,
                source.getPlayer() != null
                        ? source.getPlayer().getBoundingBox().expand(64)
                        : null,
                e -> true
        );

        if (nearbySweets.isEmpty()) {
            source.sendError(Text.literal("مفيش Sweet قريب منك. استخدم /sweet spawn الأول."));
            return 0;
        }

        SweetBotEntity sweet = nearbySweets.get(0);
        var server = source.getServer();

        sweet.respondTo(message, reply -> {
            // نرجع لـ main server thread قبل ما نبعت رسالة في الشات
            server.execute(() -> {
                server.getPlayerManager().broadcast(
                        Text.literal("<Sweet> " + reply), false
                );
            });
        });

        source.sendFeedback(() -> Text.literal("Sweet بيفكر في الرد..."), false);
        return 1;
    }

    private SweetCommands() {}
}
