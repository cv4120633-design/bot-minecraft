package com.sweet.pvpbot.config;

import com.sweet.pvpbot.SweetMod;

import java.io.IOException;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * إعدادات بسيطة للمود بتتقرا من config/sweetpvpbot.json.
 * لازم تحط api key بتاعك هنا قبل ما تستخدم أمر /sweetchat.
 *
 * مثال ملف الإعدادات اللي بيتعمل تلقائي أول مرة:
 * {
 *   "apiEndpoint": "https://api.openai.com/v1/chat/completions",
 *   "apiKey": "ضع_مفتاحك_هنا",
 *   "model": "gpt-4o-mini"
 * }
 */
public class SweetConfig {

    public String apiEndpoint = "https://api.openai.com/v1/chat/completions";
    public String apiKey = "PUT_YOUR_API_KEY_HERE";
    public String model = "gpt-4o-mini";

    private static SweetConfig instance;

    public static SweetConfig get() {
        if (instance == null) {
            load();
        }
        return instance;
    }

    public static void load() {
        Path path = Path.of("config", "sweetpvpbot.json");
        try {
            if (!Files.exists(path)) {
                Files.createDirectories(path.getParent());
                SweetConfig defaultConfig = new SweetConfig();
                try (Writer writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
                    writer.write(defaultConfig.toJson());
                }
                instance = defaultConfig;
                SweetMod.LOGGER.info("[Sweet] تم إنشاء ملف إعدادات جديد في config/sweetpvpbot.json — من فضلك حط الـ API Key بتاعك فيه.");
                return;
            }

            String content = Files.readString(path, StandardCharsets.UTF_8);
            instance = fromJson(content);
        } catch (IOException e) {
            SweetMod.LOGGER.warning("[Sweet] فشل تحميل ملف الإعدادات: " + e.getMessage());
            instance = new SweetConfig();
        }
    }

    private String toJson() {
        return "{\n"
                + "  \"apiEndpoint\": \"" + apiEndpoint + "\",\n"
                + "  \"apiKey\": \"" + apiKey + "\",\n"
                + "  \"model\": \"" + model + "\"\n"
                + "}\n";
    }

    // بارسر بسيط جدًا (خفيف) بدل ما نضيف مكتبة JSON كاملة كديبندنسي.
    // لو المود بتاعك أصلاً فيه Gson/Fabric API JSON، الأفضل تستخدمه بدل الطريقة دي.
    private static SweetConfig fromJson(String content) {
        SweetConfig config = new SweetConfig();
        config.apiEndpoint = extractValue(content, "apiEndpoint", config.apiEndpoint);
        config.apiKey = extractValue(content, "apiKey", config.apiKey);
        config.model = extractValue(content, "model", config.model);
        return config;
    }

    private static String extractValue(String content, String key, String fallback) {
        String pattern = "\"" + key + "\"\\s*:\\s*\"(.*?)\"";
        var matcher = java.util.regex.Pattern.compile(pattern).matcher(content);
        if (matcher.find()) {
            return matcher.group(1);
        }
        return fallback;
    }
}
