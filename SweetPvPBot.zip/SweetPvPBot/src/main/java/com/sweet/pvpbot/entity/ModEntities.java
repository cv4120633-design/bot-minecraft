package com.sweet.pvpbot.entity;

import com.sweet.pvpbot.SweetMod;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

/**
 * تسجيل نوع كيان "Sweet".
 * الكيان مبني فوق منطق ZombieEntity (يورث نفس الأنيميشن والرندر بتاعه)
 * عشان نتجنب الحاجة لموديل/تكستشر/رندرر مخصص من الصفر.
 */
public final class ModEntities {

    public static EntityType<SweetBotEntity> SWEET_BOT;

    public static void register() {
        SWEET_BOT = Registry.register(
                Registries.ENTITY_TYPE,
                Identifier.of(SweetMod.MOD_ID, "sweet_bot"),
                FabricEntityTypeBuilder.create(SpawnGroup.MISC, SweetBotEntity::new)
                        .dimensions(EntityDimensions.fixed(0.6f, 1.95f))
                        .build()
        );

        FabricDefaultAttributeRegistry.register(SWEET_BOT, SweetBotEntity.createSweetAttributes());
    }

    private ModEntities() {}
}
