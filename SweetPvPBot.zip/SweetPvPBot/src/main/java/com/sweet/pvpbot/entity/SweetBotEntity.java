package com.sweet.pvpbot.entity;

import com.sweet.pvpbot.ai.ChatAIService;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.world.World;

/**
 * كيان "Sweet": بوت PvP بيتصرف كأنه زومبي شغال بمنطق قتال محسّن،
 * وبيقدر كمان يرد رسائل شات عن طريق ChatAIService (اتصال بـ API خارجي).
 *
 * ليه وارث من ZombieEntity؟ عشان نستفيد من الرندرر والموديل الجاهز
 * (بيت الشكل يبقى شكل زومبي شايل اسم "Sweet" فوق راسه)، بدل ما نعمل
 * موديل وتكستشر وريندرر من الصفر. لو عايز شكل مختلف تمامًا، ده محتاج
 * موديل مخصص (resource pack / model) منفصل.
 */
public class SweetBotEntity extends ZombieEntity {

    public SweetBotEntity(EntityType<? extends ZombieEntity> entityType, World world) {
        super(entityType, world);
        this.setCustomName(Text.literal("Sweet"));
        this.setCustomNameVisible(true);
        this.equipStack(EquipmentSlot.MAINHAND, Items.IRON_SWORD.getDefaultStack());
        this.setEquipmentDropChance(EquipmentSlot.MAINHAND, 0.0f);
    }

    public static DefaultAttributeContainer.Builder createSweetAttributes() {
        return ZombieEntity.createZombieAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 40.0D)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 7.0D)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.28D)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 40.0D)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.4D);
    }

    @Override
    protected void initGoals() {
        // منطق القتال: يهاجم أقرب لاعب، بيسبح، بيلف حواليه لو مفيش هدف
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(2, new MeleeAttackGoal(this, 1.15D, true));
        this.goalSelector.add(7, new WanderAroundFarGoal(this, 0.9D));
        this.goalSelector.add(8, new LookAroundGoal(this));

        this.targetSelector.add(1, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override
    public boolean isAffectedByDaylight() {
        // منعًا لاشتعاله في الشمس زي أي زومبي عادي
        return false;
    }

    /**
     * تُستدعى من الأمر /sweetchat عشان تطلب رد من نموذج الذكاء الاصطناعي
     * وتبعته في الشات باسم Sweet.
     */
    public void respondTo(String message, java.util.function.Consumer<String> onReply) {
        ChatAIService.getInstance().askAsync(message, onReply);
    }
}
